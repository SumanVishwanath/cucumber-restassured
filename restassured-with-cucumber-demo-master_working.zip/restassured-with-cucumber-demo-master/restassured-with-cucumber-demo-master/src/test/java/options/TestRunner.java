package options;


import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/features/", glue = { "stepdefs" }, 
plugin = {"pretty"})

public class TestRunner {
	@AfterClass
	public static void writeExtentReport() {
		//Reporter.loadXMLConfig("src/main/extentreports.xml");
	}

}
