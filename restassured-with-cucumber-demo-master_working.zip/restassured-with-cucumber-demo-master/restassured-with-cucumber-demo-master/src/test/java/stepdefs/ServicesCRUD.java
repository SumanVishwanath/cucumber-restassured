package stepdefs;

import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.io.File;


import java.io.File;
import java.util.Map;

public class ServicesCRUD {
	
	private RequestSpecification request;
	RequestSpecification httpRequest = RestAssured.given().baseUri("http://localhost:3030/");
	private Response POSTRESPONSE = httpRequest.post("/services");
	private Response GETRESPONSE = httpRequest.get("/services/id");
	private Response PATCHRESPONSE = httpRequest.get("/services/");
	private Response SEARCHRESPONSE = httpRequest.get("services/");
	String filePath= System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"testData"+File.separator;
	
	private static String createdServices;
	
	@Given("^User accessess the Services create API of Best Buy \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_access_the_Services_API_of_Best_Buy (String fileName, String path)
	{ 
		File invalidjson = new File(filePath+fileName);
		System.out.println("FileName"+invalidjson);
		Response POSTRESPONSE= httpRequest.with().contentType(ContentType.JSON).body(invalidjson).
	                      when().post(path);   
		POSTRESPONSE.then().assertThat().statusCode(400);
	    
	    
		System.out.println("POST API RESPONSE "+POSTRESPONSE.asString());
	   
	}


	@Then("^Validate the mandatory fields of services create operation \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_creates_Services (String fileName1,String path )
	{
		File validjson = new File(filePath+fileName1);
		System.out.println("FileName1"+validjson);
		Response POSTRESPONSE= httpRequest.with().contentType(ContentType.JSON).
		 body(validjson).when().post(path);   
         POSTRESPONSE.then().assertThat().
         statusCode(201);
         
          createdServices= POSTRESPONSE.path("id").toString();
                 
System.out.println("POST SUCCESS Request "+POSTRESPONSE.asString());

	}
	
	@Then("^Validate whether services is Created \"([^\"]*)\"$")
	public void User_validates_createdServices_using_get_with_id (String path )
	{
	    
	    Response GETRESPONSE= httpRequest.with().pathParam("id", createdServices).when().get(path+"/{id}"); 
		
		System.out.println("createdServicesId" + createdServices);
		System.out.println("GETRESPONSE" + GETRESPONSE.asString());
		
         GETRESPONSE.then().assertThat().
         statusCode(200); 
}

	
	@Then("^Validate whether valid exception are displayed for invalid json for services \"([^\"]*)\" and path \"([^\"]*)\"$")
	 public void User_validates_exceptions(String fileName, String path) {
		File invalidjson = new File(filePath+fileName);
		System.out.println(invalidjson);
	         Response POSTRESPONSE = httpRequest.with().contentType(ContentType.JSON).body(invalidjson).
             when().post(path);   
            POSTRESPONSE.then().assertThat().statusCode(400);
            System.out.println("POST 400 BAD Request "+ POSTRESPONSE.asString());
	}

	@Then("^Validate whether server error is dispalyed for services \"([^\"]*)\"$")
	public void User_validates_server_exceptions(String path) {
		Response POSTRESPONSE = httpRequest.with().contentType(ContentType.JSON).body("testing").
	              when().post(path);   
	             POSTRESPONSE.then().assertThat().statusCode(500);
	             System.out.println("POST 500 Server Exceptions "+POSTRESPONSE.asString());	   
	}
	
	@Given("^User gets valid exception for invalid Id for services \"([^\"]*)\"$")
	public void User_validates_bad_request(String path) {
		
	 Response GETRESPONSE= httpRequest.with().when().get(path+"/ghd"); 
	  System.out.println("GET API BAD Response" + GETRESPONSE.asString());
     GETRESPONSE.then().assertThat().
     statusCode(404); 
	}
	
	@Given("^Validate whether update services API of Best Buy is functional \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_validates_update(String fileName2,String path ) {
		File updatejson = new File(filePath+fileName2);
		Response PATCHRESPONSE= httpRequest.with().pathParam("id",createdServices).contentType(ContentType.JSON).
				 body(updatejson).when().patch(path+"/{id}");   
		
		PATCHRESPONSE.then().assertThat().
		         statusCode(200).and().
		         rootPath("name").toString().equals("TestN26");
		        
		         
		         System.out.println("Updated Response "+PATCHRESPONSE.asString() );
		
	}
	
	@Then("^Validate whether valid exception are displayed for invalid update for services \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_validates_invalid_update(String fileName,String path) {
		File updatejson = new File(filePath+fileName);
		Response PATCHRESPONSE= httpRequest.with().pathParam("id","createdServices").contentType(ContentType.JSON).
				 body(updatejson).when().patch(path+"/{id}");   
		
		PATCHRESPONSE.then().assertThat().
		         statusCode(404);
		         
		        
		         
		         System.out.println("Update Operation BAD Response "+PATCHRESPONSE.asString() );
	}
	
	
	@Given("^Validate whether delete services API of Best Buy is functional \"([^\"]*)\"$") 
		public void User_validates_delete(String path) {
			Response DELETERESPONSE= httpRequest.with().pathParam("id",createdServices).contentType(ContentType.JSON).
					 when().patch(path+"/{id}");   
			System.out.println("Deleted the Services Succesfully "+DELETERESPONSE.asString() );
			
			
			DELETERESPONSE.then().assertThat().
			         statusCode(200);
			
			Response GETVALIDATION = httpRequest.with().pathParam("id",createdServices).when().get(path+"/{id}");
			       
			        if (GETVALIDATION.path("id").equals(0))
			    System.out.println("Deleted the Services Succesfully");
	}

	@Then("^Validate whether valid exception are displayed for invalid delete Id for services \"([^\"]*)\"$")
	public void User_validates_invalid_delete(String path) {
		
		Response DELETERESPONSE= httpRequest.with().pathParam("id","createdServices").contentType(ContentType.JSON).
				 when().patch(path+"/{id}");   
		
		DELETERESPONSE.then().assertThat().
		         statusCode(404);
		         
		        
		         
		         System.out.println("DELETERESPONSE Operation BAD Response "+ DELETERESPONSE.asString() );
	}
	
	@Then("^Validate whether invalid parameter of Services throws valid exception \"([^\"]*)\"$")
	public void User_validates_search_exception(String path) {
		
		 Response SEARCHRESPONSE= httpRequest.get(path+"?limit=1");
		
		 System.out.println("GET Search Response with invalid request" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(500);
		
	}
	
	@Given("^Validate whether limit query parameter of Services is functional \"([^\"]*)\"$") 
	public void User_validates_limit(String path) {
		System.out.println("Coming here");
		Response SEARCHRESPONSE = httpRequest.with().with().contentType(ContentType.JSON).when().get(path+"?$limit=2");
		
		 System.out.println("GET Search Response" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(200);	 
		String current = SEARCHRESPONSE.path("limit").toString();
		System.out.println(current);
	     
	   if(current.equals(2))
	   {
	     System.out.println("Limit is working");
	   }
	}
	@Given("^Validate whether skip query parameter of Services is functional \"([^\"]*)\"$")
	public void User_validates_skip(String path) { {
		Response SEARCHRESPONSE = httpRequest.with().contentType(ContentType.JSON).when().get(path+"?$limit=2&$skip=1");
		
		 System.out.println("GET Search Response with skip" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(200);	 
		String current = SEARCHRESPONSE.path("skip").toString();
		System.out.println(current);
	     
	   if(current.equals(1))
	   {
	     System.out.println("skip is working");
	   }
	}
	}
	
	
}