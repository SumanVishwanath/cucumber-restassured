package stepdefs;

import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.io.File;


import java.io.File;
import java.util.Map;

public class ProductCRUD {
	
	private RequestSpecification request;
	RequestSpecification httpRequest = RestAssured.given().baseUri("http://localhost:3030/");
	private Response POSTRESPONSE = httpRequest.post("/products");
	private Response GETRESPONSE = httpRequest.get("/products/id");
	private Response PATCHRESPONSE = httpRequest.get("/products/");
	private Response SEARCHRESPONSE = httpRequest.get("products/");
	String filePath= System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"testData"+File.separator;
	
	private static String createdProduct;
	
	@Given("^User accessess the product create API of Best Buy \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_access_the_product_API_of_Best_Buy (String fileName, String path)
	{ 
		File invalidjson = new File(filePath+fileName);
		System.out.println("FileName"+invalidjson);
		Response POSTRESPONSE= httpRequest.with().contentType(ContentType.JSON).body(invalidjson).
	                      when().post(path);   
		POSTRESPONSE.then().assertThat().statusCode(400);
	    
	    
		System.out.println("POST API RESPONSE "+POSTRESPONSE.asString());
	   
	}


	@Then("^Validate the mandatory fields of Products create operation \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_creates_product (String fileName1,String path )
	{
		File validjson = new File(filePath+fileName1);
		System.out.println("FileName1"+validjson);
		Response POSTRESPONSE= httpRequest.with().contentType(ContentType.JSON).
		 body(validjson).when().post(path);   
         POSTRESPONSE.then().assertThat().
         statusCode(201);
         
          createdProduct= POSTRESPONSE.path("id").toString();
                 
System.out.println("POST SUCCESS Request "+POSTRESPONSE.asString());

	}
	
	@Then("^Validate whether product is Created \"([^\"]*)\"$")
	public void User_validates_createdproduct_using_get_with_id (String path )
	{
	    
	    Response GETRESPONSE= httpRequest.with().pathParam("id", createdProduct).when().get(path+"/{id}"); 
		
		System.out.println("createdProductId" + createdProduct);
		System.out.println("GETRESPONSE" + GETRESPONSE.asString());
		
         GETRESPONSE.then().assertThat().
         statusCode(200); 
}

	
	@Then("^Validate whether valid exception are displayed for invalid json \"([^\"]*)\" and path \"([^\"]*)\"$")
	 public void User_validates_exceptions(String fileName, String path) {
		File invalidjson = new File(filePath+fileName);
		System.out.println(invalidjson);
	         Response POSTRESPONSE = httpRequest.with().contentType(ContentType.JSON).body(invalidjson).
             when().post(path);   
            POSTRESPONSE.then().assertThat().statusCode(400);
            System.out.println("POST 400 BAD Request "+ POSTRESPONSE.asString());
	}

	@Then("^Validate whether server error is dispalyed \"([^\"]*)\"$")
	public void User_validates_server_exceptions(String path) {
		Response POSTRESPONSE = httpRequest.with().contentType(ContentType.JSON).body("testing").
	              when().post(path);   
	             POSTRESPONSE.then().assertThat().statusCode(500);
	             System.out.println("POST 500 Server Exceptions "+POSTRESPONSE.asString());	   
	}
	
	@Given("^User gets valid exception for invalid Id \"([^\"]*)\"$")
	public void User_validates_bad_request(String path) {
		
	 Response GETRESPONSE= httpRequest.with().when().get(path+"/ghd"); 
	  System.out.println("GET API BAD Response" + GETRESPONSE.asString());
     GETRESPONSE.then().assertThat().
     statusCode(404); 
	}
	
	@Given("^Validate whether update products API of Best Buy is functional \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_validates_update(String fileName2,String path ) {
		File updatejson = new File(filePath+fileName2);
		Response PATCHRESPONSE= httpRequest.with().pathParam("id",createdProduct).contentType(ContentType.JSON).
				 body(updatejson).when().patch(path+"/{id}");   
		
		PATCHRESPONSE.then().assertThat().
		         statusCode(200).and().
		         rootPath("name").toString().equals("TestN26");
		        
		         
		         System.out.println("Updated Response "+PATCHRESPONSE.asString() );
		
	}
	
	@Then("^Validate whether valid exception are displayed for invalid update \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_validates_invalid_update(String fileName,String path) {
		File updatejson = new File(filePath+fileName);
		Response PATCHRESPONSE= httpRequest.with().pathParam("id","createdProduct").contentType(ContentType.JSON).
				 body(updatejson).when().patch(path+"/{id}");   
		
		PATCHRESPONSE.then().assertThat().
		         statusCode(404);
		         
		        
		         
		         System.out.println("Update Operation BAD Response "+PATCHRESPONSE.asString() );
	}
	
	
	@Given("^Validate whether delete products API of Best Buy is functional \"([^\"]*)\"$") 
		public void User_validates_delete(String path) {
			Response DELETERESPONSE= httpRequest.with().pathParam("id",createdProduct).contentType(ContentType.JSON).
					 when().patch(path+"/{id}");   
			System.out.println("Deleted the Product Succesfully "+DELETERESPONSE.asString() );
			
			
			DELETERESPONSE.then().assertThat().
			         statusCode(200);
			
			Response GETVALIDATION = httpRequest.with().pathParam("id",createdProduct).when().get("/products/{id}");
			       
			        if (GETVALIDATION.path("id").equals(0))
			    System.out.println("Deleted the Product Succesfully");
	}

	@Then("^Validate whether valid exception are displayed for invalid delete Id \"([^\"]*)\"$")
	public void User_validates_invalid_delete(String path) {
		
		Response DELETERESPONSE= httpRequest.with().pathParam("id","createdProduct").contentType(ContentType.JSON).
				 when().patch(path+"/{id}");   
		
		DELETERESPONSE.then().assertThat().
		         statusCode(404);
		         
		        
		         
		         System.out.println("DELETERESPONSE Operation BAD Response "+ DELETERESPONSE.asString() );
	}
	
	@Then("^Validate whether invalid parameter of Product throws valid exception\"([^\"]*)\"$")
	public void User_validates_search_exception(String path) {
		
		 Response SEARCHRESPONSE= httpRequest.get(path+"?limit=1");
		
		 System.out.println("GET Search Response with invalid request" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(500);
		
	}
	
	@Given("^Validate whether limit query parameter of Product is functional \"([^\"]*)\"$") 
	public void User_validates_limit(String path) {
		System.out.println("Coming here");
		Response SEARCHRESPONSE = httpRequest.with().with().contentType(ContentType.JSON).when().get(path+"?$limit=2");
		
		 System.out.println("GET Search Response" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(200);	 
		String current = SEARCHRESPONSE.path("limit").toString();
		System.out.println(current);
	     
	   if(current.equals(2))
	   {
	     System.out.println("Limit is working");
	   }
	}
	@Given("^Validate whether skip query parameter of Product is functional \"([^\"]*)\"$")
	public void User_validates_skip(String path) { {
		Response SEARCHRESPONSE = httpRequest.with().contentType(ContentType.JSON).when().get(path+"?$limit=2&$skip=1");
		
		 System.out.println("GET Search Response with skip" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(200);	 
		String current = SEARCHRESPONSE.path("skip").toString();
		System.out.println(current);
	     
	   if(current.equals(1))
	   {
	     System.out.println("skip is working");
	   }
	}
	}
	
	
}