Steps to run me right !!

-> Install any Java IDE
-> Install Cucumber plugin available in marketplace
-> clone my project repository ->
-> I'am a Maven project,hence clean install the repositories which is mandatory with pom.xml
-> Right click and execute as JUnit Test which has TestRunner -> src/main/java/options/TestRunner.java
-> Post execution, Refresh target folder and access the reports 


Thanks,Happy Coding !

Note : All my cucumber feature files are the list of manual test cases which I would like to test and In order to automate
I have used swagger extensively !!