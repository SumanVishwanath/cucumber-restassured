package stepdefs;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;


import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
 

public class utilities {

	//private Response response;
	
	private RequestSpecification request;
	RequestSpecification httpRequest = RestAssured.given().baseUri("http://localhost:3030/");
	private Response response = httpRequest.request(Method.GET, "");
	private Response healthcheck = httpRequest.get("/healthcheck");
	private Response version = httpRequest.get("/version");

	@Given("^User accessess the Health Check API of Best Buy$")
	public void user_accessess_the_Health_Check_API_of_Best_Buy() throws Throwable {
		System.out.println("json response"+healthcheck.asString());
	}
	
	@Then("^Response includes the count of Products,stores and Categories$")
	public void response_includes_the_count_of_Products_stores_and_Categories() throws Throwable {
		
			String current = healthcheck.path("documents").toString();
			
			System.out.println("documents Values" +current);

	}

	@Then("^the response status code is (\\d+)$")
	public void the_response_status_code_is(int statusCode) throws Throwable {
		int StatusCode = response.statusCode();
		healthcheck.then().assertThat().statusCode(StatusCode);
		System.out.println("json status code"+StatusCode);
		
	}


	
      @And("^Validate the response content Type is JSON$")
    public void validate_the_response_content_Type_is_JSON() throws Throwable {
	healthcheck.then().assertThat().contentType(ContentType.JSON);
		}
	
	@Given("^User accessess the Version API of Best Buy$") 
	public void user_accessess_the_Version_API_of_Best_Buy() throws Throwable {
		       
		       System.out.println("json version "+version.asString());
    
	}

	
@Then("^Response includes the version$")
public void response_includes_the_version() throws Throwable {
   version.then().assertThat().body("version", equalTo("1.1.0"));
	}
}


