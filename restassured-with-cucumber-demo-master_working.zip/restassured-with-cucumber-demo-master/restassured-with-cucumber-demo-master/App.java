package APIAutomation.TestFramework;

import org.testng.annotations.Test;;

/**
 * Hello world!
 *
 */
@Test
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
