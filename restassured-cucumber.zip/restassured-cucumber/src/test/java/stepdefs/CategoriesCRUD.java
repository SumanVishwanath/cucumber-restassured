package stepdefs;

import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.io.File;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;


import java.io.File;
import java.util.Map;

public class CategoriesCRUD {
	
//	private RequestSpecification request;
	RequestSpecification httpRequest = RestAssured.given().baseUri("http://localhost:3030/");
//	private Response POSTRESPONSE = httpRequest.post("/categories");
//	private Response GETRESPONSE = httpRequest.get("/categories/id");
//	private Response PATCHRESPONSE = httpRequest.get("/categories/");
//	private Response SEARCHRESPONSE = httpRequest.get("categories/");
	String filePath= System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"testData"+File.separator;
	
	private static String createdcategories;
	
	@Given("^User accessess the categories create API of Best Buy \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void user_accessess_the_categories_create_API_of_Best_Buy_and_path(String fileName, String path) throws Throwable {
	
		File invalidjson = new File(filePath+fileName);
		System.out.println("FileName"+invalidjson);
		Response POSTRESPONSE= httpRequest.with().contentType(ContentType.JSON).body(invalidjson).
	                      when().post(path);   
		POSTRESPONSE.then().assertThat().statusCode(400);
	    
	    
		System.out.println("POST API RESPONSE "+POSTRESPONSE.asString());
	   
	}


	@Then("^Validate the mandatory fields of categories create operation \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void validate_the_mandatory_fields_of_categories_create_operation_and_path(String fileName1, String path) throws Throwable {
		File validjson = new File(filePath+fileName1);
		System.out.println("FileName1"+validjson);
		Response POSTRESPONSE= httpRequest.with().contentType(ContentType.JSON).
		 body(validjson).when().post(path);   
         POSTRESPONSE.then().assertThat().
         statusCode(201);
         
          createdcategories= POSTRESPONSE.path("id").toString();
                 
System.out.println("POST SUCCESS Request "+POSTRESPONSE.asString());

	}
	
	@Given("^Validate whether categories is Created \"([^\"]*)\"$")
	public void validate_whether_categories_is_Created(String path) throws Throwable  {
	{
	    
	    Response GETRESPONSE= httpRequest.with().pathParam("id", createdcategories).when().get(path+"/{id}"); 
		
		System.out.println("createdcategoriesId" + createdcategories);
		System.out.println("GETRESPONSE" + GETRESPONSE.asString());
		
         GETRESPONSE.then().assertThat().statusCode(200);
         }
	}
	
	@Given("^User gets valid exception for invalid Id for categories \"([^\"]*)\"$")
	public void user_gets_valid_exception_for_invalid_Id_for_categories(String path) throws Throwable {
		{
		    
		    Response GETRESPONSE= httpRequest.with().pathParam("id","createdcategories").when().get(path+"/{id}"); 
			
			System.out.println("createdcategoriesId" + createdcategories);
			System.out.println("GETRESPONSE" + GETRESPONSE.asString());
			
	         GETRESPONSE.then().assertThat().statusCode(404);
	         }
		}


	@Given("^Validate whether server error is displayed for categories \"([^\"]*)\"$")
	public void validate_whether_server_error_is_displayed_for_categories(String path) throws Throwable {
		Response POSTRESPONSE = httpRequest.with().contentType(ContentType.JSON).body("testing").
	              when().post(path);   
	             POSTRESPONSE.then().assertThat().statusCode(500);
	             System.out.println("POST 500 Server Exceptions "+POSTRESPONSE.asString());	   
	}
	
	@Given("^Validate whether valid exception are displayed for invalid json for categories \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void validate_whether_valid_exception_are_displayed_for_invalid_json_for_categories_and_path(String fileName, String path) throws Throwable {
		
	 Response GETRESPONSE= httpRequest.with().when().get(path+"/ghd"); 
	  System.out.println("GET API BAD Response" + GETRESPONSE.asString());
     GETRESPONSE.then().assertThat().statusCode(404);
	}
	
	@Given("^Validate whether update categories API of Best Buy is functional \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_validates_update(String fileName2,String path ) {
		File updatejson = new File(filePath+fileName2);
		Response PATCHRESPONSE= httpRequest.with().pathParam("id",createdcategories).contentType(ContentType.JSON).
				 body(updatejson).when().patch(path+"/{id}");   
		
		PATCHRESPONSE.then().assertThat().
		         statusCode(200).and().
		         rootPath("name").toString().equals("TestN26");
		        
		         
		         System.out.println("Updated Response "+PATCHRESPONSE.asString() );
		
	}
	
	@Then("^Validate whether valid exception are displayed for invalid update for categories \"([^\"]*)\" and path \"([^\"]*)\"$")
	public void User_validates_invalid_update(String fileName,String path) {
		File updatejson = new File(filePath+fileName);
		Response PATCHRESPONSE= httpRequest.with().pathParam("id","createdcategories").contentType(ContentType.JSON).
				 body(updatejson).when().patch(path+"/{id}");   
		
		PATCHRESPONSE.then().assertThat().
		         statusCode(404);
		         
		        
		         
		         System.out.println("Update Operation BAD Response "+PATCHRESPONSE.asString() );
	}
	
	
	@Given("^Validate whether delete categories API of Best Buy is functional \"([^\"]*)\"$")
	public void validate_whether_delete_categories_API_of_Best_Buy_is_functional(String path) throws Throwable {
			Response DELETERESPONSE= httpRequest.with().pathParam("id",createdcategories).contentType(ContentType.JSON).
					 when().delete(path+"/{id}");   
			System.out.println("Deleted the categories Succesfully "+DELETERESPONSE.asString() );
			
			
			DELETERESPONSE.then().assertThat().
			         statusCode(200);
			
			Response GETVALIDATION = httpRequest.with().pathParam("id",createdcategories).when().get(path+"/{id}");
			       
			      GETVALIDATION.then().assertThat().statusCode(404);
			    System.out.println("Deleted the categories Succesfully"+GETVALIDATION);
	}

	@Given("^Validate whether valid exception are displayed for invalid delete Id for categories \"([^\"]*)\"$")
	public void validate_whether_valid_exception_are_displayed_for_invalid_delete_Id_for_categories(String path) throws Throwable {
		
		Response DELETERESPONSE= httpRequest.with().pathParam("id","createdcategories").contentType(ContentType.JSON).
				 when().delete(path+"/{id}");   
		
		DELETERESPONSE.then().assertThat().
		         statusCode(404);
		         
		        
		         
		         System.out.println("DELETERESPONSE Operation BAD Response "+ DELETERESPONSE.asString() );
	}
	
	@Given("^Validate whether invalid parameter of categories throws valid exception \"([^\"]*)\"$")
	public void validate_whether_invalid_parameter_of_categories_throws_valid_exception(String path) throws Throwable {
		
		 Response SEARCHRESPONSE= httpRequest.get(path+"?limit=1");
		
		 System.out.println("GET Search Response with invalid request" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(500);
		
	}
	
	@Given("^Validate whether limit query parameter of categories is functional \"([^\"]*)\"$")
	public void validate_whether_limit_query_parameter_of_categories_is_functional(String path) throws Throwable {
		System.out.println("Coming here");
		Response SEARCHRESPONSE = httpRequest.with().with().contentType(ContentType.JSON).when().get(path+"?$limit=2");
		
		 System.out.println("GET Search Response" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(200);	 
		String current = SEARCHRESPONSE.path("limit").toString();
		System.out.println(current);
	     
	   if(current.equals(2))
	   {
	     System.out.println("Limit is working");
	   }
	}
	@Given("^Validate whether skip query parameter of categories is functional \"([^\"]*)\"$")
	public void validate_whether_skip_query_parameter_of_categories_is_functional(String path) throws Throwable {
		Response SEARCHRESPONSE = httpRequest.with().contentType(ContentType.JSON).when().get(path+"?$limit=2&$skip=1");
		
		 System.out.println("GET Search Response with skip" + SEARCHRESPONSE.asString());
		
		SEARCHRESPONSE.then().assertThat().statusCode(200);	 
		String current = SEARCHRESPONSE.path("skip").toString();
		System.out.println(current);
	     
	   if(current.equals(1))
	   {
	     System.out.println("skip is working");
	   }
	}
	
}
