package stepdefs;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;


import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
 

public class utilitiesModules {

	//private Response response;
	
	private RequestSpecification request;
	RequestSpecification httpRequest = RestAssured.given().baseUri("http://localhost:3030/");
	private Response response = httpRequest.request(Method.GET, "");
	private Response healthcheck = httpRequest.get("/healthcheck");
	private Response version = httpRequest.get("/version");

	@Given("^User accessess the Health Check API of Best Buy$")
		public void User_access_the_URL_of_Best_Buy (){
	       System.out.println("json response"+healthcheck.asString());
	
	}

	@Then("the response status code is (\\d+)")
	public void verify_status_code(int statusCode){
		int StatusCode = response.statusCode();
		healthcheck.then().assertThat().statusCode(StatusCode);
		System.out.println("json status code"+StatusCode);
		
	}

	@And("Response includes the count of Products,stores and Categories$")
	public void response_equals(){
		
		String current = healthcheck.path("documents").toString();
		
		System.out.println("documents Values" +current);
				                 
				                                                                 
			}
	
	@And("^Validate the response content Type is JSON$")
		public void schemavalidation(){
		healthcheck.then().assertThat().contentType(ContentType.JSON);
		
	}
	
	@Given("^User accessess the Version API of Best Buy$") 
		public void User_access_the_Version_of_Best_Buy (){
		       
		       System.out.println("json version "+version.asString());
	    
	}
	
	
	@Then("^Response includes the version$")
	public void response_version(){
	   version.then().assertThat().body("version", equalTo("1.1.0"));
	}
}


