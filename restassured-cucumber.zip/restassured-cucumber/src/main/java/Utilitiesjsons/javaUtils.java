package Utilitiesjsons;



import org.junit.Ignore;
import org.junit.Test;;

/**
 * Hello world!
 *
 */
@Ignore
public class javaUtils 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
